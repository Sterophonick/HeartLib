#define SFX_COMPLETE	0
#define MOD_MODULE	0
#define MSL_NSONGS	1
#define MSL_NSAMPS	32
#define MSL_BANKSIZE	33
extern const u8 soundbank_bin_end[];
extern const u8 soundbank_bin[];
extern const u32 soundbank_bin_size;

